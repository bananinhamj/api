<script>
import MenuLateral from "@/components/MenuLateral.vue";
import CabeCalho from "@/components/CabeCalho.vue";
import PrincIpal from "@/components/PrincIpal.vue";
import RodaPe from "@/components/RodaPe.vue";
export default {
  components: { MenuLateral, CabeCalho, PrincIpal, RodaPe },
};
</script>
<template>
  <MenuLateral />
  <CabeCalho />
  <PrincIpal />
  <RodaPe />
</template>
<style></style>
