<script>
export default {};
</script>
<template>
  <article class="block">
    <img src="@/assets/img/cadeira.jpg" />
    <p></p>
  </article>
</template>
<style></style>
