<script>
export default {};
</script>
<template>
  <footer id="footer">

  </footer>
</template>
<style></style>
