<script>
export default {};
</script>
<template>
  <article class="block">
    <img class="estraordinaria" src="@/assets/img/celta.jpg" />
    <p></p>
  </article>
</template>
<style></style>
