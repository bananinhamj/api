<script>
export default {};
</script>
<template>
  <article class="block">
    <img src="@/assets/img/porta.jpg" />
    <p></p>
  </article>
</template>
<style></style>
