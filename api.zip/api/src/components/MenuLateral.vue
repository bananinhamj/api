<script>
export default {};
</script>
<template>
  <aside id="sidenav">
    <p class="lateral"></p>
    <p class="lateral"></p>
    <p class="lateral"></p>
    <p class="lateral"></p>
    <p class="lateral"></p>
    <p class="lateral"></p>
    <p class="lateral"></p>
  </aside>
</template>
<style></style>
