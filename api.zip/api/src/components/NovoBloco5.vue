<script>
export default {};
</script>
<template>
  <article class="block">
    <img src="@/assets/img/mesa.jpg" />
    <p></p>
  </article>
</template>
<style></style>
