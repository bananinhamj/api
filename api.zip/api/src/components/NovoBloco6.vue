<script>
export default {};
</script>
<template>
  <article class="block">
    <img src="@/assets/img/folha.jpg" />
    <p></p>
  </article>
</template>
<style></style>
