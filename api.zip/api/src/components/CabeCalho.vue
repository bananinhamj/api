<script>
export default {};
</script>
<template>
  <header id="header">
    <h1 class="titulo">KDRAMABOOK</h1>
    
  </header>
</template>
<style>
</style>
