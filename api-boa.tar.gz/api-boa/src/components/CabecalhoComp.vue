<script>
export default {};
</script>
<template>
  <header id="header">
    <h1 class="titulo">Kdramabook</h1>
  </header>
</template>
<style></style>
