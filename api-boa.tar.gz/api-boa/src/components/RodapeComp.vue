<script>
export default {};
</script>
<template>
  <footer id="footer">
    <p>rodapé</p>
  </footer>
</template>
<style></style>
