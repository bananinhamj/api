<script>
import NovoBloco1 from "@/components/NovoBloco1.vue";
import NovoBloco2 from "@/components/NovoBloco2.vue";
import NovoBloco3 from "@/components/NovoBloco3.vue";
import NovoBloco4 from "@/components/NovoBloco4.vue";
import NovoBloco5 from "@/components/NovoBloco5.vue";
import NovoBloco6 from "@/components/NovoBloco6.vue";
export default {
  components: {
    NovoBloco1,
    NovoBloco2,
    NovoBloco3,
    NovoBloco4,
    NovoBloco5,
    NovoBloco6,
  },
};
</script>
<template>
  <main id="content">
    <NovoBloco1 />
    <NovoBloco2 />
    <NovoBloco3 />
    <NovoBloco4 />
    <NovoBloco5 />
    <NovoBloco6 />
  </main>
</template>
<style></style>
